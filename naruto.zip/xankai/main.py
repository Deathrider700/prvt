from pyrogram import Client
import json

# Load configuration data
with open("FILES/config.json", "r", encoding="utf-8") as f:
    DATA = json.load(f)
    API_ID = DATA["API_ID"]
    API_HASH = DATA["API_HASH"]
    BOT_TOKEN = DATA["BOT_TOKEN"]

# Initialize bot client
bot = Client(
    "Telegram",
    api_id=API_ID,         # Your API ID
    api_hash=API_HASH,     # Your API Hash
    bot_token=BOT_TOKEN,   # Your Bot Token
    plugins=dict(root="BOT")
)

if __name__ == "__main__":
    print("Done Bot Active ✅")
    print("NOW START BOT ONCE MY MASTER")
    bot.run()